#ifndef __GPUHASH_H__
#define __GPUHASH_H__

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <cuda.h>
#include <cuda_runtime.h>

#include <thrust/scan.h>
#include <thrust/device_vector.h>
#include <thrust/sort.h>
#include <thrust/reduce.h>
#include <thrust/iterator/zip_iterator.h>
#include <thrust/pair.h>

#include "Bucket.h"
#include "CudaLib.h"

class GPUHash {

private:

    // Point to Memory on the CPU which has GPU pointer
    Bucket* buckets;
    // Random seed for bucket placement
    unsigned long long int random_seed_bucket;
    // Number of elements in the hash map
    int num_elem;
    // Number of buckets in the hash map
    int num_bucket;

    // Create the Buckets
    void createBuckets();
    // Clears the element count of buckets
    void clearBucketCount();
    // Increase buckets by factor
    void increaseBucket(thrust::device_vector<KeyValDone>& keyVect,
                        const int factor);
    // Decrease buckets by factor
    void decreaseBucket();
    // Determine if I need to get a new bucket hash
    bool newBucketHash(int num_left);
    // Fill the Buckets
    void fillBuckets(thrust::device_vector<KeyValDone>& keyVect,
                     const int len);
    // Empty out the table and return the table
    void emptyHashTable(thrust::device_vector<KeyValDone>& keyVect);
    // Rebalances the buckets not yet balanced
    void rebalanceBuckets(thrust::device_vector<KeyValDone>& keyVect,
                          const int num_left,
                          const int len);

public:

    // Constructor
    GPUHash(int* key, int* val, int len);

    // Destroy all the memory regions
    ~GPUHash();

    // Adds to the existing hash table
    void insertHashTable(int* key, int* val, int len);
 
    // Removes from the existing hash table
    void removeHashTable(int* key, int len);
    
    // Find the value of keys from the hash table
    void lookupTable(int* key, int* val_results, int len);

};

#endif
