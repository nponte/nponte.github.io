#ifndef __BUCKET_H__
#define __BUCKET_H__

#include <atomic>
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>

// Bucket implementation of the hash map

class Bucket {

private:
 
    //Storage on the GPU
    long long int* storage;
    //Two hash functions for this bucket
    unsigned long long int hash1;
    unsigned long long int hash2;
    unsigned long long int hash3;
    int size;

public:

    bool alive;

    int num_elem;

    void init_fields(int _size);

    void clear_fields();

    bool get_alive();

    __host__ __device__ void set_alive();

    void clear_alive();

    __host__ __device__ long long int get_slot(int i, unsigned int hash);

    long long int* get_storage();

    void set_hash1(unsigned long long int _hash1);
 
    void set_hash2(unsigned long long int _hash2);
 
    void set_hash3(unsigned long long int _hash3);
 
    __host__ __device__ unsigned long long int get_hash1();
  
    __host__ __device__ unsigned long long int get_hash2();
   
    __host__ __device__ unsigned long long int get_hash3();

    __device__ unsigned long long int add_slot(int key, int val, int i, unsigned int hash);
  
    __device__ bool clear_slot(int c_key, unsigned int c_hash1, 
                               unsigned int c_hash2, unsigned int c_hash3);
};

#endif
