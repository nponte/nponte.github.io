#!/bin/bash

# Select job queue 
#PBS -q tesla

#Move to my $SCRATCH directory
cd $SCRATCH


execdir=/home/nponte/418
exe=Hash.sh
makefile=Makefile

# Copy exectable to $SCRATCH
cp ${execdir}/${exe} ${exe}
cp ${execdir}/${makefile} ${makefile}

# Run executable 
./${exe} 
