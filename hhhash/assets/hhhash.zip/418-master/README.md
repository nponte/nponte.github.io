Legion - Could be Used for Managing the Memory Regions on the GPU's


GPU - HashTable

3 - Area of Focus - 
