#ifndef __SLOT_H__
#define __SLOT_H__

#include <stdio.h>

// Slot is a abstraction of (Key,Val)

class Slot {

private:
 
    //Key and Value for this slot
    int key;
    int val;

public:

    // Construct the bucket
    Slot(int _key, int _val);

    // Get and Set for Key and Val
    void set_key(int _key);

    void set_val(int _val);

    int get_key();

    int get_val();
  
    // Clears the slot
    void clear_slot();

    //Destroy everything
    ~Slot();

};

#endif
