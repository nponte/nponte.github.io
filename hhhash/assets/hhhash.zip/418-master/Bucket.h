#ifndef __BUCKET_H__
#define __BUCKET_H__

#include <atomic>
#include <cuda.h>
#include <cuda_runtime.h>
#include <stdio.h>

// Bucket implementation of the hash map

class Bucket {

private:
 
    //Storage on the GPU
    long long int* storage;
    //Two hash functions for this bucket
    int hash1;
    int hash2;
    int size;

public:

    bool alive;

    int num_elem;

    void init_fields(int _size);

    void clear_fields();

    bool get_alive();

    __host__ __device__ void set_alive();

    void clear_alive();

    __host__ __device__ long long int get_slot(unsigned int hash);

    long long int* get_storage();

    void set_hash1(int _hash1);
 
    void set_hash2(int _hash2);
 
    __host__ __device__ int get_hash1();
  
    __host__ __device__ int get_hash2();
   
    __device__ unsigned long long int add_slot(int key, int val, unsigned int hash);
  
    __device__ void clear_slot(unsigned int hash);
};

#endif
