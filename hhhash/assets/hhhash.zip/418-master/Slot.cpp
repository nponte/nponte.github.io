#include "Slot.h"

Slot::Slot(int _key, int _val) 
{
  key = _key;
  val = _val;
}

void Slot::set_key(int _key) 
{
  key = _key; 
}

void Slot::set_val(int _val) 
{
  val = _val;
}

int Slot::get_key() 
{
  return key;
}

int Slot::get_val()
{
  return val;
}

void Slot::clear_slot()
{
  key = 0;
  val = 0;
}
