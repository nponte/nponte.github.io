#ifndef __CUDALIB_H__
#define __CUDALIB_H__

typedef thrust::pair<long long int,bool> KeyValDone;

void clearAlive(Bucket* dev_buckets, int num_bucket);

__host__ __device__ int get_key(long long int keyval);

__host__ __device__ int get_val(long long int keyval);

__host__ __device__ unsigned int hashKey(const int key, const int seed);

__global__ void remove_kernel(int len, int num_bucket, int bucket_seed, int* key,
                              Bucket* buckets);

static inline int updiv(int n, int d);

void combineVec(int* key, int* val, int len, int offset, 
                thrust::device_vector<KeyValDone>& keyVect);

int generateNewOddRandomSeed(int oldNum1);

void generateBucketRandomSeeds(Bucket* b);

#endif
